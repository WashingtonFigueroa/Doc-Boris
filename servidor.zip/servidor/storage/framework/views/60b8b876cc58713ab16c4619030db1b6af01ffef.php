Radiografía: <?php echo e($filename); ?> <br>
Hora de creación: <?php echo e($created_at->format('d/m/Y H:i:s')); ?>


