Radiografía: {{ $filename }} <br>
Hora de creación: {{ $created_at->format('d/m/Y H:i:s') }}

